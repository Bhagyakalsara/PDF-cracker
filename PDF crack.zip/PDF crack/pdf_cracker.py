import os
import subprocess

# Set the path to your PDF file
pdf_path = "/home/menda/Documents/PDF crack/11287_protected.pdf"  # Change this to your actual file path
hash_file = "hash.txt"

# Check if pdf2john.py exists, if not, download it
if not os.path.exists("pdf2john.py"):
    print("[+] Downloading pdf2john.py...")
    subprocess.run(["wget", "https://raw.githubusercontent.com/openwall/john/bleeding-jumbo/run/pdf2john.py", "-O", "pdf2john.py"])
    subprocess.run(["chmod", "+x", "pdf2john.py"])

# Extract the hash from the PDF
print("[+] Extracting hash from PDF...")
subprocess.run(f"python3 pdf2john.py '{pdf_path}' > {hash_file}", shell=True)

# Check if the hash file was created
if not os.path.exists(hash_file) or os.path.getsize(hash_file) == 0:
    print("[-] Failed to extract hash. Make sure the PDF is password protected.")
    exit(1)

# Crack the hash using John the Ripper
print("[+] Cracking the password with John the Ripper...")
subprocess.run(f"john --wordlist=/usr/share/wordlists/rockyou.txt {hash_file}", shell=True)

# Show the cracked password
print("[+] Checking results...")
subprocess.run(f"john --show --format=PDF {hash_file}", shell=True)
